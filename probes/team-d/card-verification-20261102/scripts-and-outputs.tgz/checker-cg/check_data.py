import json, re, sys
FENCE = "`" * 3
spec, root = open(sys.argv[1]).read(), sys.argv[2]
cards_src = open(root + "/src/shared/content/Cards.luau").read()
cfg_src = open(root + "/src/shared/progression/Config.luau").read()
def block(kind): return re.search(FENCE + kind + r"\n(.*?)\n" + FENCE, spec, re.S).group(1)
cards = [json.loads(l) for l in block("jsonl").splitlines() if l.startswith("{") and '"alias"' in l]
bad = 0
for c in cards:
    blk = cards_src[cards_src.index('id = "%s"' % c["id"]):][:600]
    for k, v in (("hp", c["hp"]), ("atk", c["atk"]), ("def", c["def"]), ("speed", c["speed"])):
        if not re.search(r"\b%s = %d\b" % (k, v), blk): print("CARD MISMATCH", c["id"], k); bad += 1
cfg = json.loads(block("json"))
pairs = {"ROLL_COOLDOWN_S": cfg["roll"]["ROLL_COOLDOWN_S"], "PITY_FAILS": cfg["roll"]["PITY_FAILS"],
         "REWARD_WIN_XP": cfg["rewards"]["REWARD_WIN_XP"], "REWARD_BOSS_CURRENCY": cfg["rewards"]["REWARD_BOSS_CURRENCY"],
         "EARNED_PACK_COST": cfg["store"]["EARNED_PACK_COST"], "SESSION_LEASE_S": cfg["limits"]["SESSION_LEASE_S"]}
for k, v in pairs.items():
    if int(re.search(r"Config\.%s\s*=\s*(\d+)" % k, cfg_src).group(1)) != v: print("CONFIG MISMATCH", k); bad += 1
rl = {a: [int(b), int(c)] for a, b, c in re.findall(r"(\w+) = \{ interval = (\d+), burst = (\d+) \}", cfg_src)}
if rl != {k: v for k, v in cfg["rate_limits"].items() if isinstance(v, list)}: print("RATE LIMIT MISMATCH"); bad += 1
print(len(cards), "cards checked;", "mismatches:", bad)