local Cards = dofile("./src/shared/content/Cards.luau")
local Config = dofile("./src/shared/progression/Config.luau")
local Statuses = dofile("./src/shared/combat/Statuses.luau")
local Resolver = dofile("./src/shared/combat/Resolver.luau")
local Bootstrap = dofile("./src/server/Bootstrap.luau")
local function q(s) return '"'..tostring(s)..'"' end
print("CARDS")
for _,e in ipairs(Cards.EDITIONS) do
  print(string.format('%s|%s|%s|%s|%d|%d|%d|%d|%s|%s|%s|%s|%s', e.id,e.alias,e.rarity,e.role,e.hp,e.atk,e.def,e.speed,e.entry,tostring(e.starter),tostring(e.boss==true),tostring(e.mythic),tostring(e.legacy)))
end
print("NODES")
for _,n in ipairs(Config.SKILL_NODES) do print(n.id,n.branch,n.maxRanks,n.atkBp,n.hpBp,n.xpBp) end
print("ROUTES")
local ed,edb,enc = Bootstrap.contentTables(Cards)
local ids={} for k in pairs(enc) do ids[#ids+1]=k end table.sort(ids)
for _,k in ipairs(ids) do local e=enc[k] print(k,e.chapter,e.enemyIds[1],tostring(e.requiresClear),tostring(e.isBoss)) end
print("RANKS") for _,r in ipairs(Config.RANKS) do print(r.id,r.points,r.minRun) end
print("RATES") local rk={} for k in pairs(Config.RATE_LIMITS) do rk[#rk+1]=k end table.sort(rk) for _,k in ipairs(rk) do print(k,Config.RATE_LIMITS[k].interval,Config.RATE_LIMITS[k].burst) end
print("MISC")
for _,k in ipairs({"ROLL_COOLDOWN_S","PITY_FAILS","ROLL_WEIGHT_TOTAL","DECK_MIN","DECK_MAX","REWARD_WIN_XP","REWARD_WIN_CURRENCY","REWARD_BOSS_XP","REWARD_BOSS_CURRENCY","CARD_XP_WIN","CARD_XP_LOSS","MAX_CARD_LEVEL","MAX_RUN_LEVEL","MAX_ACCOUNT_LEVEL","CARD_TRAINED_BP_PER_LEVEL","MASTERY_RANK_COUNT","MASTERY_POINTS_PER_RANK","MASTERY_MAX_POINTS","MASTERY_ATK_BP_MAX","MASTERY_HP_BP_MAX","MASTERY_XP_BP_MAX","EARNED_PACK_ID","EARNED_PACK_COST","LEGACY_STORY_ROUTE_ID","LEGACY_STORY_REWARD_ID","AWAY_CATCH_UP_CAP_S","MAX_DUP_COUNT","MAX_COLLECTION_IDS","MAX_CATALOGUE_IDS","MAX_PENDING_ROLLS","MAX_RECENT_OPS","MAX_CURRENCY","MAX_XP","MAX_STRING_LEN","MAX_TABLE_DEPTH","MAX_TABLE_WIDTH","MAX_FIGHTER_STAT","MAX_BATTLE_TURNS","SESSION_LEASE_S","SCHEMA_VERSION","PROGRESSION_VERSION","RULES_VERSION","CONTENT_VERSION"}) do print(k,tostring(Config[k])) end
print("CAPS",table.concat(Config.CHAPTER_CAPS,","))
print("STARTERS",table.concat(Config.STARTER_IDS,","))
print("AWAYRATE",Config.AWAY_REWARD_RATES.runXpPerHour)
print("VOL",Config.DEFAULT_VOLUMES.musicVolume,Config.DEFAULT_VOLUMES.sfxVolume,Config.DEFAULT_VOLUMES.uiVolume,Config.DEFAULT_VOLUMES.ambienceVolume)
print("STAT",Statuses.BURN_POWER,Statuses.BURN_TICKS,Statuses.ENTRY_SHIELD,Statuses.STUN_TICKS,Resolver.MAX_TURNS,Resolver.MAX_EVENTS)
print("WEIGHTS") for _,w in ipairs(Config.ROLL_WEIGHTS_10000) do print(w.rarity,w.weight) end
