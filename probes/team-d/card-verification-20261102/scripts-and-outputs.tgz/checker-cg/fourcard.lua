local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local function wins(ids, L, chapter, enemy)
  local lv = {} for _, id in ipairs(ids) do lv[id]=L end
  local w=0
  for s=1,200 do
    local mine = assert(Battles.buildSnapshot(ids, by, lv, chapter, {atk=1,hp=1}))
    local foe = assert(Battles.buildEnemySnapshot({enemy}, by))
    if assert(Resolver.resolveBattle(mine, foe, {rulesVersion="provisional-1", seed=s*7919})).snapshot.winner=="A" then w=w+1 end
  end
  return w
end
local E4={"BK-GUTS-01","NR-SHADOW-01","VG-RIVAL-01","MHA-BLAST-01"}
local C4={"NR-NARUTO-01","VS-THORFINN-01","BC-ASTA-01","VG-HEAD-01"}
local LOW={"VG-HEAD-01","NR-NARUTO-01","BK-WIND-01","BC-WIND-01"}
print("4 Epics L1 vs boss-1,boss-2,boss-3,w3-enc-1:", wins(E4,1,3,"NR-KAKASHI-01"), wins(E4,1,3,"DB-PRINCE-01"), wins(E4,1,3,"MHA-FROSTBURN-01"), wins(E4,1,1,"BK-GUTS-01"))
print("4 Commons L1 vs boss-1,boss-2,boss-3,w3-enc-1:", wins(C4,1,3,"NR-KAKASHI-01"), wins(C4,1,3,"DB-PRINCE-01"), wins(C4,1,3,"MHA-FROSTBURN-01"), wins(C4,1,1,"BK-GUTS-01"))
print("LOW4 L10 vs boss-3:", wins(LOW,10,3,"MHA-FROSTBURN-01"), " vs boss-1:", wins(LOW,10,3,"NR-KAKASHI-01"))
-- other 4-Epic combos with DB-PRINCE
local E4b={"BK-GUTS-01","NR-SHADOW-01","DB-PRINCE-01","MHA-BLAST-01"}
print("Epics incl Prince L1 vs boss-1/2/3:", wins(E4b,1,3,"NR-KAKASHI-01"), wins(E4b,1,3,"DB-PRINCE-01"), wins(E4b,1,3,"MHA-FROSTBURN-01"))
-- single epic alone
for _,id in ipairs({"BK-GUTS-01","NR-SHADOW-01","VG-RIVAL-01","MHA-BLAST-01","DB-PRINCE-01"}) do
  io.write(id," alone L1 vs boss-1/2/3: ", wins({id},1,3,"NR-KAKASHI-01")," ",wins({id},1,3,"DB-PRINCE-01")," ",wins({id},1,3,"MHA-FROSTBURN-01"),"\n") end
