local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local Config   = dofile(ROOT.."progression/Config.luau")
local Prog     = dofile(ROOT.."progression/Progression.luau")
local Validate = dofile(ROOT.."combat/Validate.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
-- counts
local rc, fr = {}, {}
for _, e in ipairs(Cards.EDITIONS) do rc[e.rarity]=(rc[e.rarity] or 0)+1; fr[e.franchise]=(fr[e.franchise] or 0)+1 end
print("n editions", #Cards.EDITIONS)
for _,k in ipairs({"Common","Uncommon","Rare","Epic","Legendary","Mythic"}) do io.write(k,"=",rc[k]," ") end print()
local nf=0 for k,v in pairs(fr) do nf=nf+1 io.write(k,"=",v," ") end print("franchises",nf)
-- bounds
local bad=0
for _, e in ipairs(Cards.EDITIONS) do
  if e.hp<20 or e.hp>120 or e.atk<3 or e.atk>20 or e.def<0 or e.def>10 or e.speed<1 or e.speed>20 then bad=bad+1 end end
print("out-of-bound cards", bad)
-- starter flags/boss/mythic/legacy
local st,bo,my,lg={}, {}, {}, {}
for _, e in ipairs(Cards.EDITIONS) do if e.starter then st[#st+1]=e.id end if e.mythic then my[#my+1]=e.id end if e.legacy then lg[#lg+1]=e.id end if e.boss then bo[#bo+1]=e.id end end
print("starter flags", table.concat(st,","))
print("boss flags", table.concat(bo,","))
print("mythic", table.concat(my,","), "legacy", table.concat(lg,","))
-- stun scratch: player deck [weak, Byakuya]; enemy single strong card
local function snap(ids) local o={} for i,id in ipairs(ids) do local e=by[id] o[i]={cardId=id,hp=e.hp,maxHp=e.hp,atk=e.atk,def=e.def,speed=e.speed,shield=0,status={name="none",ticks=0,power=0},entry=e.entry or "none"} end return o end
-- Make a weak first card (hp 5) so it falls; then Byakuya enters -> stun on enemy
local A=snap({"VG-HEAD-01","BL-BYAKUYA-01"}); A[1].hp=5; A[1].maxHp=5
local B=snap({"NR-KAKASHI-01"})
local r=Resolver.resolveBattle(A,B,{seed=12345,rulesVersion="provisional-1"})
local stunskip=0
for _,ev in ipairs(r.events) do
  if ev.kind=="entry_effect" or (ev.kind=="status_tick") or ev.kind=="status_expired" or ev.kind=="replacement" or ev.kind=="ko" then io.write(ev.seq,":",ev.kind,"/",tostring(ev.status or ev.card),"/side",tostring(ev.side),"/turn",tostring(ev.turn)," | ") end
  if ev.status=="stun-skip" then stunskip=stunskip+1 end
end
print() print("stun-skip events:",stunskip)
-- show strikes around the entry
for _,ev in ipairs(r.events) do if tonumber(ev.turn) and tonumber(ev.turn)<=3 then io.write(ev.kind,"(",tostring(ev.side),")") io.write(" ") end end print()
-- 720 combos: float vs integer bp
local mism=0
for _,e in ipairs(Cards.EDITIONS) do for eff=1,15 do for _,k in ipairs({"hp","atk"}) do
  local f=math.floor(e[k]*1*(1+0.06*(eff-1)))
  local i=(e[k]*(10000+0)*(10000+600*(eff-1)))//100000000
  local code
  local lv={} lv[e.id]=eff
  local fs=Battles.buildSnapshot({e.id},by,lv,5,{atk=1,hp=1})  -- chapter 5 => cap 30 so eff = level
  code=fs[1][k]
  if f~=i or code~=i then mism=mism+1 if mism<10 then print("MISMATCH",e.id,eff,k,f,i,code) end end
end end end
print("720-combo mismatches (float formula vs integer bp vs code):", mism)
local n=by["NR-NARUTO-01"]
for _,eff in ipairs({6,10,15}) do local lv={["NR-NARUTO-01"]=eff} local s=Battles.buildSnapshot({"NR-NARUTO-01"},by,lv,5,{atk=1,hp=1}) io.write("eff",eff,": hp ",s[1].hp," atk ",s[1].atk,"; ") end print()
-- skill example: atk 9 * 1.06 floor; hp 58*1.06
local s=Battles.buildSnapshot({"NR-NARUTO-01"},by,{["NR-NARUTO-01"]=1},1,{atk=1.06,hp=1.06}) print("L1 +6%:",s[1].hp,s[1].atk)
local s=Battles.buildSnapshot({"NR-NARUTO-01"},by,{["NR-NARUTO-01"]=10},3,{atk=1.06,hp=1.06}) print("L10 +6%:",s[1].hp,s[1].atk)
-- pity maths
local q=1-0.0005
print("P(reach pity)=",q^1799," E draws=",(1-q^1800)/(1-q))
-- expected rolls to collect 4 of 5 epics
local E=0 for k=0,3 do E=E+5/(5-k) end print("epic draws",E,"rolls",E/0.045,"minutes",E/0.045*6/60)
-- XP table
local cum=function(L) return 25*L*(L-1)//2 end
print("cumxp L6,L10,L15",cum(6),cum(10),cum(15))
-- first full clear
print("coins",9*10+3*50,"xp",9*20+3*100)
-- Validate team range
for k,v in pairs(Validate) do if type(v)~="function" then print("Validate."..k,v) end end
