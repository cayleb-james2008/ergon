local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local Config   = dofile(ROOT.."progression/Config.luau")
local Prog     = dofile(ROOT.."progression/Progression.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local S3 = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01" }
local SEC = { strike=0.55, damage=0.13, shield_absorb=0.13, status_applied=0.13, status_tick=0.13, entry_effect=0.13, ko=0.40, replacement=0.40 }
local function fight(lv, chapter, enemy, seed)
  local mine = assert(Battles.buildSnapshot(S3, by, lv, chapter, { atk = 1, hp = 1 }))
  local foe  = assert(Battles.buildEnemySnapshot({ enemy }, by))
  local r = assert(Resolver.resolveBattle(mine, foe, { rulesVersion = "provisional-1", seed = seed }))
  local t=0 for _, ev in ipairs(r.events) do t = t + (SEC[ev.kind] or 0.05) end
  return r.snapshot.winner, t
end
-- farm N wins on one route
for _, r in ipairs({ {"enc-1",1,"BL-ICHIGO-01"}, {"enc-2",2,"VS-THORFINN-01"}, {"enc-3",3,"BC-ASTA-01"} }) do
  local lv, xp, total, tot15 = {}, {}, 0, 0
  for _, id in ipairs(S3) do lv[id]=1 xp[id]=0 end
  for n = 1, 45 do
    local w, t = fight(lv, r[2], r[3], n*7919)
    assert(w=="A")
    total = total + t
    for _, id in ipairs(S3) do lv[id], xp[id] = Prog.applyCardXp(lv[id], xp[id], 25, Config.cardXpNext) end
    if n==15 then tot15=total end
  end
  print(r[1], string.format("15 wins = %.1f s (%.1f min); 45 wins = %.1f min", tot15, tot15/60, total/60))
end
-- full path to first boss-2 win with farming exactly to L6 on enc-3, then w2-enc-1..3, boss-2
local lv, xp = {}, {}
for _, id in ipairs(S3) do lv[id]=1 xp[id]=0 end
local total=0
for n=1,15 do local w,t=fight(lv,3,"BC-ASTA-01",n*7919) total=total+t for _,id in ipairs(S3) do lv[id],xp[id]=Prog.applyCardXp(lv[id],xp[id],25,Config.cardXpNext) end end
print("after 15 enc-3 wins level", lv[S3[1]], string.format("%.1f s",total))
for i,rt in ipairs({{"w2-enc-1",1,"VG-MUSASHI-01"},{"w2-enc-2",2,"MHA-DEKU-01"},{"w2-enc-3",3,"BC-SEA-01"},{"boss-2",3,"DB-PRINCE-01"}}) do
  local w,t=fight(lv,rt[2],rt[3],7919*i) total=total+t print(rt[1],w,string.format("%.1f s",t)) for _,id in ipairs(S3) do lv[id],xp[id]=Prog.applyCardXp(lv[id],xp[id],25,Config.cardXpNext) end
end
print(string.format("total to first boss-2 win: %.1f s = %.1f min (19 duels incl. unlock wins enc-1,enc-2 not counted)", total, total/60))
