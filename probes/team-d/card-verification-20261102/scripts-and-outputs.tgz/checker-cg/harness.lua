local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local STARTERS = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01" }   -- STARTER_IDS order, player = side A
local ROUTES = {                                                         -- id, chapter, enemy card
  {"enc-1",1,"BL-ICHIGO-01"},{"enc-2",2,"VS-THORFINN-01"},{"enc-3",3,"BC-ASTA-01"},{"boss-1",3,"NR-KAKASHI-01"},
  {"w2-enc-1",1,"VG-MUSASHI-01"},{"w2-enc-2",2,"MHA-DEKU-01"},{"w2-enc-3",3,"BC-SEA-01"},{"boss-2",3,"DB-PRINCE-01"},
  {"w3-enc-1",1,"BK-GUTS-01"},{"w3-enc-2",2,"VG-RIVAL-01"},{"w3-enc-3",3,"MHA-BLAST-01"},{"boss-3",3,"MHA-FROSTBURN-01"} }
local SECONDS = { strike=0.55, damage=0.13, shield_absorb=0.13, status_applied=0.13, status_tick=0.13,
                  entry_effect=0.13, ko=0.40, replacement=0.40 }          -- everything else 0.05 s
local function fight(ids, level, chapter, enemy, seed)
  local lv = {} for _, id in ipairs(ids) do lv[id] = level end
  local mine = assert(Battles.buildSnapshot(ids, by, lv, chapter, { atk = 1, hp = 1 }))
  local foe  = assert(Battles.buildEnemySnapshot({ enemy }, by))
  return assert(Resolver.resolveBattle(mine, foe, { rulesVersion = "provisional-1", seed = seed }))
end
for _, level in ipairs({ 1, 3, 6, 10, 15 }) do
  local row = {}
  for _, r in ipairs(ROUTES) do
    local wins, secs = 0, 0
    for s = 1, 200 do
      local res = fight(STARTERS, level, r[2], r[3], s * 7919)
      if res.snapshot.winner == "A" then wins = wins + 1 end
      for _, ev in ipairs(res.events) do secs = secs + (SECONDS[ev.kind] or 0.05) end
    end
    row[#row + 1] = string.format("%s %d/200 (%.1fs)", r[1], wins, secs / 200)
  end
  print("level " .. level .. ": " .. table.concat(row, " | "))
end