import math
cam=(0,6.5,11); look=(0,3.5,0); vfov=55
d=[look[i]-cam[i] for i in range(3)]; n=math.sqrt(sum(x*x for x in d)); f=[x/n for x in d]
# right = +x (looking toward -z), up = perpendicular
up=(0, -f[2]/math.hypot(f[1],f[2])*1, 0)  # placeholder
# up = right x forward? compute generally: world up (0,1,0)
def cross(a,b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def norm(a): m=math.sqrt(sum(x*x for x in a)); return tuple(x/m for x in a)
right=norm(cross(f,(0,1,0))); upv=cross(right,f)
print("pitch deg",math.degrees(math.asin(-f[1])),"right",right,"up",upv)
t=math.tan(math.radians(vfov/2))
def proj(P,aspect):
    v=[P[i]-cam[i] for i in range(3)]
    dep=sum(v[i]*f[i] for i in range(3)); x=sum(v[i]*right[i] for i in range(3)); u=sum(v[i]*upv[i] for i in range(3))
    return x/(dep*t*aspect), u/(dep*t), dep
def visible_frac(aspect, cx, w=2.6, h=3.6, cy=4.0, n=400):
    # fraction of card AREA whose projected ndc_x in [-1,1]; also width fraction per row
    inside=0; tot=0; rows=[]
    for j in range(n):
        y=cy-h/2+(j+0.5)*h/n
        rowin=0
        for i in range(n):
            x=cx-w/2+(i+0.5)*w/n
            nx,ny,_=proj((x,y,0),aspect)
            ok = abs(nx)<=1 and abs(ny)<=1
            rowin+=ok; inside+=ok; tot+=1
        rows.append(rowin/n)
    return inside/tot, rows[0], rows[n//2], rows[-1]
for W,H in [(390,844),(375,812),(360,800),(430,932),(393,852),(844,390),(1280,720),(1440,900),(1920,1080)]:
    a=W/H
    # half-width at card plane at card centre height (y=4) and at top/bottom
    out=[]
    for y in (5.8,4.0,2.2):
        nx,ny,dep=proj((1,y,0),a)  # x=1 -> nx
        out.append(dep*t*a)
    rest=visible_frac(a,-3.2)[0]
    wind=visible_frac(a,-3.65)[0]
    outer=visible_frac(a,-3.2)
    # also centre line visible-x half width
    print(f"{W}x{H} aspect {a:.4f}: half-width at card plane top/mid/bottom = {out[0]:.3f}/{out[1]:.3f}/{out[2]:.3f} studs; resting card area visible = {rest*100:.1f}% (row top {outer[1]*100:.1f}% mid {outer[2]*100:.1f}% bottom {outer[3]*100:.1f}%); wound-up (x=-3.65) = {wind*100:.1f}%")
    # simple width fraction at mid height: (hw - 1.9)/2.6
    hw=out[1]; print("    simple mid-height width fraction =", max(0,min(1,(hw-1.9)/2.6))*100)
# control bar overlap
for H in (720,844,900,1080,390):
    nx,ny,dep=proj((0,2.2,0),0.5)
    ycard=(1+(-ny))*H/2  # ny negative below centre -> larger y
    ycard=(1-ny)*H/2
    bar_top=0.79*H-160
    print(H,"card bottom y",round(ycard,1),"control bar top",round(bar_top,1),"overlap",round(ycard-bar_top,1))
