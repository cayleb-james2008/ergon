#!/usr/bin/env bash
cd "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate"
L=/home/cayleb/Work/projects/untitled-street-game/.tools/bin/lune
for s in progression presentation integration server offers; do
  ( time timeout 800 lua tests/$s/run_all.luau ) > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lua-$s.out 2>&1; echo "exit $?" >> /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lua-$s.out
  ( time timeout 800 $L run tests/$s/run_all ) > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-$s.out 2>&1; echo "exit $?" >> /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-$s.out
done
( time timeout 800 $L run tests/run_all ) > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-combat.out 2>&1; echo "exit $?" >> /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-combat.out
for t in integration/test_starter_journey studio/test_studio_checks; do n=$(echo $t | tr / _)
  ( time timeout 800 lua tests/$t.luau ) > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lua-$n.out 2>&1; echo "exit $?" >> /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lua-$n.out
  ( time timeout 800 $L run tests/$t ) > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-$n.out 2>&1; echo "exit $?" >> /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/t-lune-$n.out
done
echo done > /tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/checker-cg/tests-done.flag
