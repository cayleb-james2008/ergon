local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local STARTERS = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01" }
local ROUTES = {
  {"enc-1",1,"BL-ICHIGO-01"},{"enc-2",2,"VS-THORFINN-01"},{"enc-3",3,"BC-ASTA-01"},{"boss-1",3,"NR-KAKASHI-01"},
  {"w2-enc-1",1,"VG-MUSASHI-01"},{"w2-enc-2",2,"MHA-DEKU-01"},{"w2-enc-3",3,"BC-SEA-01"},{"boss-2",3,"DB-PRINCE-01"},
  {"w3-enc-1",1,"BK-GUTS-01"},{"w3-enc-2",2,"VG-RIVAL-01"},{"w3-enc-3",3,"MHA-BLAST-01"},{"boss-3",3,"MHA-FROSTBURN-01"} }
local function wins(ids, level, chapter, enemy)
  local lv = {} for _, id in ipairs(ids) do lv[id] = level end
  local w, rounds = 0, 0
  for s = 1, 200 do
    local mine = assert(Battles.buildSnapshot(ids, by, lv, chapter, { atk = 1, hp = 1 }))
    local foe  = assert(Battles.buildEnemySnapshot({ enemy }, by))
    local res = assert(Resolver.resolveBattle(mine, foe, { rulesVersion = "provisional-1", seed = s*7919 }))
    if res.snapshot.winner == "A" then w = w + 1 end
    rounds = rounds + res.snapshot.turns
  end
  return w, rounds/200
end
local decks = {
  starters = STARTERS,
  starters_plus_dojo = {"NR-NARUTO-01","VS-THORFINN-01","BC-ASTA-01","VG-HEAD-01"},
}
local perms = {{1,2,3},{1,3,2},{2,1,3},{2,3,1},{3,1,2},{3,2,1}}
for name, ids in pairs(decks) do
  print("== deck "..name)
  for _, r in ipairs(ROUTES) do
    local row, first_any, first_all = {}, nil, nil
    for L = 1, 15 do
      local w = wins(ids, L, r[2], r[3])
      row[#row+1] = w
      if w > 0 and not first_any then first_any = L end
      if w == 200 and not first_all then first_all = L end
    end
    print(string.format("%-9s L1..15: %s | first>0: %s | first 200/200: %s", r[1], table.concat(row, ","), tostring(first_any), tostring(first_all)))
  end
end
-- permutation sensitivity for starters, level 10 and the thresholds
print("== starter order sensitivity (wins/200)")
for _, p in ipairs(perms) do
  local ids = {STARTERS[p[1]], STARTERS[p[2]], STARTERS[p[3]]}
  local res = {}
  for _, rr in ipairs({{"boss-1",3,"NR-KAKASHI-01",10},{"boss-1",3,"NR-KAKASHI-01",9},{"boss-2",3,"DB-PRINCE-01",6},{"boss-2",3,"DB-PRINCE-01",5},{"boss-3",3,"MHA-FROSTBURN-01",7},{"boss-3",3,"MHA-FROSTBURN-01",6}}) do
    res[#res+1] = rr[1].."@L"..rr[4].."="..wins(ids, rr[4], rr[2], rr[3])
  end
  -- level 10 all routes
  local all200 = true
  for _, r in ipairs(ROUTES) do if wins(ids, 10, r[2], r[3]) ~= 200 then all200 = false end end
  print(table.concat(ids, ">"), table.concat(res, " "), "L10 all12=200:", tostring(all200))
end
