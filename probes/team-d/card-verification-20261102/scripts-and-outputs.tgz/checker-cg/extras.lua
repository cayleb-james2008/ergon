local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local Config   = dofile(ROOT.."progression/Config.luau")
local Prog     = dofile(ROOT.."progression/Progression.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local S3 = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01" }
local S4 = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01", "VG-HEAD-01" }
local SEC = { strike=0.55, damage=0.13, shield_absorb=0.13, status_applied=0.13, status_tick=0.13, entry_effect=0.13, ko=0.40, replacement=0.40 }
local function fight(ids, levels, chapter, enemy, seed)
  local mine = assert(Battles.buildSnapshot(ids, by, levels, chapter, { atk = 1, hp = 1 }))
  local foe  = assert(Battles.buildEnemySnapshot({ enemy }, by))
  return assert(Resolver.resolveBattle(mine, foe, { rulesVersion = "provisional-1", seed = seed }))
end
local function same(ids, L) local t = {} for _, id in ipairs(ids) do t[id] = L end return t end
local function wins(ids, L, chapter, enemy)
  local w, rounds = 0, 0
  for s = 1, 200 do local r = fight(ids, same(ids, L), chapter, enemy, s * 7919)
    if r.snapshot.winner == "A" then w = w + 1 end; rounds = rounds + r.snapshot.turns end
  return w, rounds / 200
end
for L = 7, 10 do
  print("L"..L, "starters vs boss-1", (wins(S3, L, 3, "NR-KAKASHI-01")),
        "| +Dojo vs boss-1", (wins(S4, L, 3, "NR-KAKASHI-01")), "| starters vs boss-3", (wins(S3, L, 3, "MHA-FROSTBURN-01")))
end
for _, deck in ipairs({ {"BK-GUTS-01","NR-SHADOW-01","VG-RIVAL-01","MHA-BLAST-01"}, {"NR-NARUTO-01","VS-THORFINN-01","BC-ASTA-01","VG-HEAD-01"} }) do
  print(deck[1].." deck level 1 vs boss-1/2/3:", (wins(deck,1,3,"NR-KAKASHI-01")), (wins(deck,1,3,"DB-PRINCE-01")), (wins(deck,1,3,"MHA-FROSTBURN-01")))
end
for _, r in ipairs({ {"enc-1",1,"BL-ICHIGO-01"}, {"enc-2",2,"VS-THORFINN-01"}, {"enc-3",3,"BC-ASTA-01"} }) do
  local lv, xp, total = same(S3, 1), {}, 0
  for _, id in ipairs(S3) do xp[id] = 0 end
  for _ = 1, 45 do
    local res = fight(S3, lv, r[2], r[3], 7919)
    for _, ev in ipairs(res.events) do total = total + (SEC[ev.kind] or 0.05) end
    for _, id in ipairs(S3) do lv[id], xp[id] = Prog.applyCardXp(lv[id], xp[id], Config.CARD_XP_WIN, Config.cardXpNext) end
  end
  print(r[1], string.format("45 wins at 1x = %.1f min (seed 7919 each duel)", total / 60))
end