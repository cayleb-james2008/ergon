local ROOT = "/tmp/claude-1000/-home-cayleb-Work/ae3da1fa-e00b-44d9-8428-93a167393f60/scratchpad/cg-candidate/src/shared/"
local Resolver = dofile(ROOT.."combat/Resolver.luau")
local Cards    = dofile(ROOT.."content/Cards.luau")
local Battles  = dofile(ROOT.."progression/Battles.luau")
local by = {} for _, e in ipairs(Cards.EDITIONS) do by[e.id] = e end
local ST = { "NR-NARUTO-01", "VS-THORFINN-01", "BC-ASTA-01" }
local ROUTES = {
  {"enc-1",1,"BL-ICHIGO-01"},{"enc-2",2,"VS-THORFINN-01"},{"enc-3",3,"BC-ASTA-01"},{"boss-1",3,"NR-KAKASHI-01"},
  {"w2-enc-1",1,"VG-MUSASHI-01"},{"w2-enc-2",2,"MHA-DEKU-01"},{"w2-enc-3",3,"BC-SEA-01"},{"boss-2",3,"DB-PRINCE-01"},
  {"w3-enc-1",1,"BK-GUTS-01"},{"w3-enc-2",2,"VG-RIVAL-01"},{"w3-enc-3",3,"MHA-BLAST-01"},{"boss-3",3,"MHA-FROSTBURN-01"} }
local function avg(L, r)
  local lv = {} for _, id in ipairs(ST) do lv[id]=L end
  local tot=0
  for s=1,200 do
    local mine = assert(Battles.buildSnapshot(ST, by, lv, r[2], {atk=1,hp=1}))
    local foe = assert(Battles.buildEnemySnapshot({r[3]}, by))
    tot = tot + assert(Resolver.resolveBattle(mine, foe, {rulesVersion="provisional-1", seed=s*7919})).snapshot.turns
  end
  return tot/200
end
for _, r in ipairs(ROUTES) do
  local t={} for _,L in ipairs({1,3,6,10,15}) do t[#t+1]=string.format("%.1f",avg(L,r)) end
  print(r[1], table.concat(t," | "))
end
