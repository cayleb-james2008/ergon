local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local NS = tonumber(arg[1]) or 10
local tw, tn, farmCounts = 0, 0, {}
local bossSeen = 0
for seed = 1, NS do
  local g = H.new(seed, {quiet = true})
  P.starterDeck(g)
  local n = 0
  while true do
    local lv = P.cardLevels(g); local m = 99
    for _, id in ipairs(g:profileRaw().run.deck) do m = math.min(m, lv[id] or 1) end
    if m >= 10 then break end
    P.fight(g, "enc-1", "skip"); n = n + 1
  end
  farmCounts[#farmCounts+1] = n
  for rep = 1, 3 do
    for _, rt in ipairs({"enc-1","enc-2","enc-3","w2-enc-1","w2-enc-2","w2-enc-3","w3-enc-1","w3-enc-2","w3-enc-3","boss-1","boss-2","boss-3"}) do
      local w = P.fight(g, rt, "skip"); tn = tn + 1; if w == "A" then tw = tw + 1 else print("LOSS", seed, rt) end
    end
  end
  if seed == 1 then g:say("(seed 1) legacy/Goku after boss-3: retained=%s", table.concat(g:profile().retained.legacy, ",")) end
end
print("wins to reach level 10 with 3 starters on enc-1 (per seed):", table.concat(farmCounts, ","))
print(string.format("then 12 routes x3 through the UI/real server across %d seeds: %d / %d won", NS, tw, tn))
