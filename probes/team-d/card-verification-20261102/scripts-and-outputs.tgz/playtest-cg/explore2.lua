local H = dofile(os.getenv("PLAYDIR").."/harness.lua")
local g = H.new(5)
g:press("tutorial-next")
print("calls before save:", table.concat(g.calls,","))
g:press("deck-save","empty deck")
print("calls:", table.concat(g.calls,","))
for _,r in ipairs(g.refusals) do print("REFUSAL",r.cmd,r.status,r.reason) end
print("deck on profile:", table.concat(g:profile().deck,","), "screen", g:cur())
