-- Session D: a player who rolls first. N free rolls (waiting the 6s cooldown each time), best-4 deck, then the guided path to the first boss win.
local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local N = tonumber(arg[1]) or 30
local seed = tonumber(arg[2]) or 1
local verbose = arg[3] == "v"
local g = H.new(seed, {quiet = not verbose})
local CardsById = {}
for _, e in ipairs(H.Cards.EDITIONS) do CardsById[e.id] = e end
local rank = {Common=1,Uncommon=2,Rare=3,Epic=4,Legendary=5,Mythic=6}
local function score(id) local e = CardsById[id]; return rank[e.rarity] * 1000 + e.atk * 10 + e.hp end
g:press("tutorial-roll")
local got = {}
for i = 1, N do
  g:press("roll-free"); g:wait(6.2, true)
  local r = g.app.lastRoll; if r then got[r.rarity] = (got[r.rarity] or 0) + 1 end
end
local function buildDeck()
  P.to(g, "deck")
  -- clear the draft then pick best four
  local n = #g.app.deckDraft
  for _ = 1, n do g:press("drm-1") end
  local owned = {}
  for id in pairs(g:profile().collection) do owned[#owned+1] = id end
  table.sort(owned, function(a, b) return score(a) > score(b) end)
  for i = 1, math.min(4, #owned) do g:press("add-" .. owned[i]) end
  g:press("deck-save")
  return owned
end
local owned = buildDeck()
local deck = g:profileRaw().run.deck
local names = {}
for _, id in ipairs(deck) do names[#names+1] = CardsById[id].rarity:sub(1,3) .. ":" .. CardsById[id].alias end
g:say("after %d rolls (%s) deck = %s", N, (function() local t = {} for k, v in pairs(got) do t[#t+1] = k .. v end table.sort(t) return table.concat(t, " ") end)(), table.concat(names, ", "))
local battles, losses, streak, watchEq = 0, 0, 0, 0
local rollsExtra = 0
while not g:profileRaw().run.bossClaimed and battles < 300 do
  P.to(g, "worlds")
  g:press("worlds-next")
  local tl = g.app.battle.timeline
  for _, e in ipairs(tl.events) do watchEq = watchEq + H.Timeline.eventDuration(tl, e) end
  g:playBattle("skip")
  local w = g.app.lastBattleWinner
  g:press("reward-claim")
  battles = battles + 1
  if w == "A" then streak = 0 else losses = losses + 1; streak = streak + 1 end
  if streak >= 4 then   -- gives up on the wall and rolls 30 more, then rebuilds
    P.to(g, "roll")
    for i = 1, 30 do g:press("roll-free"); g:wait(6.2, true); rollsExtra = rollsExtra + 1 end
    buildDeck(); streak = 0
  end
end
local d = g:profileRaw()
local lv = d.run.cardLevels
local ml = 99 for _, id in ipairs(d.run.deck) do ml = math.min(ml, lv[id] or 1) end
local cleared = {} for k in pairs(d.run.encounters) do cleared[#cleared+1] = k end table.sort(cleared)
print(string.format("RESULT N=%d seed=%d battles=%d losses=%d extraRolls=%d actions=%d bossWon=%s clock_s=%.0f watch_equiv_s=%.0f min_deck_level=%d cleared=%s", N, seed, battles, losses, rollsExtra, g.actions, tostring(d.run.bossClaimed), g.t - g.t0, watchEq, ml, table.concat(cleared, ",")))
