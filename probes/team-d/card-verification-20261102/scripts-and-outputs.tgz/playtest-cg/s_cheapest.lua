-- Session B1: cheapest honest route (uses outside knowledge of the maths): fresh profile -> first boss win -> skills -> first rebirth.
local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local seed = tonumber(arg[1]) or 1
local mode = arg[2] or "watch"
local quiet = arg[3] ~= "v"
local FARM = arg[4] or "enc-1"
local g = H.new(seed, {quiet = quiet})
local battles, wins, losses = 0, 0, 0
local need = {["enc-1"]=1,["enc-2"]=1,["enc-3"]=1,["w2-enc-1"]=2,["w2-enc-2"]=3,["w2-enc-3"]=4,["boss-2"]=6}
local function minLevel()
  local lv = P.cardLevels(g); local m = 99
  for _, id in ipairs(g:profileRaw().run.deck) do m = math.min(m, lv[id] or 1) end
  return m
end
local function fightTo(route)
  while true do
    local w, st = P.fight(g, route, mode)
    battles = battles + 1
    if w == "A" then wins = wins + 1; g:mark("first win claimed"); P.watchMarks(g, wins) return true end
    losses = losses + 1; g:say("LOST on %s (%s)", route, tostring(st)); P.watchMarks(g, wins)
    if battles > 200 then return false end
  end
end
g:read("START")
P.starterDeck(g)
for _, rt in ipairs({"enc-1","enc-2","enc-3","w2-enc-1","w2-enc-2","w2-enc-3","boss-2"}) do
  while minLevel() < need[rt] do fightTo(FARM) end
  if rt == "boss-2" then g:say("cards at level %d; attempting boss-2", minLevel()) end
  fightTo(rt)
end
g:mark("first boss win claimed")
-- claim skill points, spend them
P.to(g, "upgrade")
g:read("upgrade")
g:press("rank-claim")
g:read("after rank claim")
-- rebirth
P.to(g, "rebirth")
g:read("rebirth screen")
g:press("rebirth-preview")
g:read("rebirth preview")
g:press("rebirth-confirm")
g:mark("first rebirth confirmed")
g:read("after rebirth")
local lv = P.cardLevels(g)
print(string.format("RESULT seed=%d mode=%s battles=%d wins=%d losses=%d actions=%d total_s=%.0f forced_s=%.0f human_s=%.0f", seed, mode, battles, wins, losses, g.actions, g.t - g.t0, g.forcedS, g.humanS))
for k, v in pairs(g.marks) do print(string.format("  MARK %-32s actions=%3d t=%s forced=%s", k, v.actions, H.fmt(v.secs), H.fmt(v.forced))) end
