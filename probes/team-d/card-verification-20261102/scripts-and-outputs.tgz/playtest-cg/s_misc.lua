local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
print("=== M1. Start a duel with NO saved deck ===")
do
  local g = H.new(21, {quiet = true})
  P.to(g, "worlds"); g:press("route-enc-1")
  print("screen:", g:cur(), "| status:", g:status())
  for _, r in ipairs(g.refusals) do print("  refusal:", r.cmd, r.reason) end
end
print("=== M2. Auto-roll toggle ===")
do
  local g = H.new(22, {quiet = true})
  P.to(g, "roll")
  print("label before:", g:buttonText("autoroll-toggle"))
  for i = 1, 3 do g:press("autoroll-toggle"); print(" after press "..i..": label=", g:buttonText("autoroll-toggle"), "| server autoRoll =", g:profileRaw().run.autoRoll, "| client pref =", g.app.store.prefs.autoRoll) end
  -- what would auto-roll do if it were on? ask the server by flag fixture
  local d = g:profileRaw()
  local ident = g.h.store.identity(g.h.store, g.userId, "fx-auto", math.floor(g.t), { epoch = d.session.epoch, seq = d.run.reqHighWater + 1 })
  ident.op.expectedRevision = ident.revision
  g.h.store.runOp(g.h.store, g.userId, ident.op, function(c) c.run.autoRoll = true; return c, {}, nil end)
  g:press("roll-refresh")
  print(" with the flag forced on (fixture), label=", g:buttonText("autoroll-toggle"))
  g:press("autoroll-toggle"); print(" pressing it now sends enabled=false -> server autoRoll =", g:profileRaw().run.autoRoll)
end
print("=== M3. Full cheapest run, then scan every screen for level/XP words, shop, rebirth, run 2 ===")
local g = H.new(23, {quiet = true})
local need = {["enc-1"]=1,["enc-2"]=1,["enc-3"]=1,["w2-enc-1"]=2,["w2-enc-2"]=3,["w2-enc-3"]=4,["boss-2"]=6}
local function minL() local lv = P.cardLevels(g); local m = 99 for _, id in ipairs(g:profileRaw().run.deck) do m = math.min(m, lv[id] or 1) end return m end
local function cheapestRun()
  local n = 0
  for _, rt in ipairs({"enc-1","enc-2","enc-3","w2-enc-1","w2-enc-2","w2-enc-3","boss-2"}) do
    while minL() < need[rt] do P.fight(g, "enc-1", "skip"); n = n + 1 end
    repeat local w = P.fight(g, rt, "skip"); n = n + 1 until w == "A"
  end
  return n
end
P.starterDeck(g)
print("run 1 duels to first boss win:", cheapestRun())
-- dump all screens
local words = {"level", "Level", "LV", "Lv", "lvl"}
local hits = {}
local all = {}
for id, s in pairs(g.app.screens) do
  local texts = {}
  if s.data then texts[#texts+1] = s.data.Text end
  if s.feedback then texts[#texts+1] = s.feedback.Text end
  for bid, b in pairs(s.buttons) do texts[#texts+1] = b.Text end
  for _, t in ipairs(texts) do for _, w in ipairs(words) do if t and t:find(w, 1, true) then hits[#hits+1] = id .. ": " .. t:gsub("\n", " / ") end end end
end
print("texts on any of the 13 screens containing 'level'/'Lv' (excluding Rebirth 'Resets:' field list):")
for _, h in ipairs(hits) do print("   ", h) end
print("battle HUD labels:", g.app.hud.refs.TopHP.Text)
local d = g:profileRaw()
print("(hidden) card levels", table.concat((function() local t = {} for k, v in pairs(d.run.cardLevels) do t[#t+1] = k.."="..v end table.sort(t) return t end)(), " "), "run level", d.run.level, "xp", d.run.xp, "coins", d.run.currency)
-- inventory card text vs sealed battle stats
P.to(g, "inventory"); g:press("inspect-NR-NARUTO-01")
print("inventory inspector shows:", (g.app.screens.inventory.data.Text:gsub("\n", " / ")))
local f = H.Battles.buildSnapshot({"NR-NARUTO-01"}, H.Bootstrap.contentTables(H.Cards) and select(2, H.Bootstrap.contentTables(H.Cards)), d.run.cardLevels, 3, {atk=1,hp=1})
print("while the same card in a chapter-3 duel actually has hp/atk =", f[1].hp, f[1].atk)
-- shop
P.to(g, "store"); g:read("shop (coins=" .. d.run.currency .. ")")
g:press("store-purchase")
print("shop status:", g:status())
-- upgrade & rebirth
P.to(g, "upgrade"); g:press("rank-claim")
P.to(g, "rebirth"); g:press("rebirth-preview"); print("PREVIEW TEXT:\n"..g.app.screens.rebirth.data.Text)
g:press("rebirth-confirm")
print("after confirm: screen", g:cur(), "status:", g:status(), "run", g:profile().runNumber, "deck", #g:profile().deck, "skill points", g:profile().skillPoints)
local d2 = g:profileRaw()
print("(hidden) run2 coins", d2.run.currency, "levels", table.concat((function() local t = {} for k, v in pairs(d2.run.cardLevels) do t[#t+1] = k.."="..v end table.sort(t) return t end)(), " "), "cleared", next(d2.run.encounters))
P.starterDeck(g)
print("run 2 duels to first boss win:", cheapestRun())
P.to(g, "upgrade"); g:read("upgrade (run 2)"); g:press("rank-claim")
print("rank claim run 2 ->", g:status(), "| points now", g:profile().skillPoints)
