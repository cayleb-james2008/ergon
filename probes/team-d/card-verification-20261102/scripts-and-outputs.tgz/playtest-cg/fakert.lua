-- Extracted verbatim (lines 58-246) from the repo's tests/presentation/test_app.luau: its strict fake Roblox runtime.
-- STRICT fake signal.
local function FakeSignal()
	return {
		listeners = {},
		Connect = function(self, fn)
			assert(type(fn) == "function", "Connect needs a function")
			self.listeners[#self.listeners + 1] = fn
			return { Disconnect = function() end }
		end,
		Fire = function(self, ...)
			for _, fn in ipairs(self.listeners) do
				fn(...)
			end
		end,
	}
end

local function isColor3(v)
	return type(v) == "table" and v.__type == "Color3"
end
local function isCFrame(v)
	return type(v) == "table" and v.__type == "CFrame"
end
local function isVector3(v)
	return type(v) == "table" and v.__type == "Vector3"
end
local function isUDim2(v)
	return type(v) == "table" and v.__type == "UDim2"
end
local function isVector2(v)
	return type(v) == "table" and v.__type == "Vector2"
end
local automaticSizeY = { enumType = "AutomaticSize", name = "Y" }

-- Property contract per class. ScreenGui: Enabled ONLY (Visible rejected).
-- R2: genuine Roblox layout/focus props (Position, AnchorPoint,
-- BackgroundTransparency, Selectable, LayoutOrder) are accepted — they are
-- real engine properties, not test holes; hex-into-Color3, Visible on
-- ScreenGui and table-into-CFrame stay rejected.
local SCHEMA = {
	ScreenGui = { Enabled = "bool", ResetOnSpawn = "bool" },
	Frame = { BackgroundColor3 = "color3", BackgroundTransparency = "number",
		Visible = "bool", Size = "udim2", Position = "udim2",
		AnchorPoint = "vector2", LayoutOrder = "number" },
	ScrollingFrame = { BackgroundColor3 = "color3",
		BackgroundTransparency = "number", Visible = "bool",
		Size = "udim2", Position = "udim2", AnchorPoint = "vector2",
		CanvasSize = "udim2", AutomaticCanvasSize = "automatic-size",
		ScrollBarThickness = "number", ScrollingDirection = "string" },
	TextLabel = { Text = "string", TextSize = "number", TextWrapped = "bool",
		TextScaled = "bool", TextColor3 = "color3", BackgroundColor3 = "color3",
		BackgroundTransparency = "number", Size = "udim2", Position = "udim2",
		AnchorPoint = "vector2", Visible = "bool", Selectable = "bool",
		LayoutOrder = "number" },
	TextButton = { Text = "string", TextSize = "number", TextWrapped = "bool",
		TextScaled = "bool", TextColor3 = "color3", BackgroundColor3 = "color3",
		BackgroundTransparency = "number", Size = "udim2", Position = "udim2",
		AnchorPoint = "vector2", Visible = "bool", Selectable = "bool",
		LayoutOrder = "number" },
	Part = { CFrame = "cframe", Orientation = "vector3", Transparency = "number",
		Anchored = "bool", CanCollide = "bool", CanTouch = "bool",
		CanQuery = "bool", Size = "vector3", Position = "vector3",
		Shape = "string", Material = "string", TopSurface = "string",
		BottomSurface = "string", Color = "color3" },
	Camera = { CameraType = "string", FieldOfView = "number", CFrame = "cframe" },
	Folder = {},
	SurfaceGui = { Face = "string", ClipsDescendants = "bool",
		AlwaysFaceCamera = "bool" },
	ImageLabel = { Image = "string", BackgroundTransparency = "number",
		Size = "udim2", ClipsDescendants = "bool", ScaleType = "string" },
	UIListLayout = { Padding = "udim", FillDirection = "string" },
	UIPadding = { PaddingTop = "udim", PaddingLeft = "udim",
		PaddingRight = "udim", PaddingBottom = "udim" },
	PointLight = { Color = "color3" },
}

local META_FIELDS = { ClassName = true, Name = true, Parent = true,
	Children = true, Destroyed = true, Activated = true, Attributes = true }

local function checkType(class, key, v)
	local want = SCHEMA[class][key]
	if want == "bool" then
		assert(type(v) == "boolean", class .. "." .. key .. " needs bool")
	elseif want == "string" then
		assert(type(v) == "string", class .. "." .. key .. " needs string")
	elseif want == "number" then
		assert(type(v) == "number", class .. "." .. key .. " needs number")
	elseif want == "color3" then
		assert(isColor3(v), class .. "." .. key .. " needs Color3 (got "
			.. type(v) .. " — hex strings rejected)")
	elseif want == "cframe" then
		assert(isCFrame(v), class .. "." .. key .. " needs CFrame")
	elseif want == "vector3" then
		assert(isVector3(v), class .. "." .. key .. " needs Vector3")
	elseif want == "udim2" then
		assert(isUDim2(v), class .. "." .. key .. " needs UDim2")
	elseif want == "vector2" then
		assert(isVector2(v), class .. "." .. key .. " needs Vector2")
	elseif want == "automatic-size" then
		assert(v == automaticSizeY,
			class .. "." .. key .. " needs Enum.AutomaticSize.Y")
	end
end

local function FakeInst(class)
	assert(SCHEMA[class] ~= nil, "strict fake rejects class " .. tostring(class))
	local inst = {
		ClassName = class, Name = "", Children = {},
		Destroyed = false, Attributes = {},
	}
	if class == "TextButton" then
		inst.Activated = FakeSignal()
	end
	inst.Destroy = function(self)
		self.Destroyed = true
	end
	inst.SetAttribute = function(self, k, v)
		self.Attributes[k] = v
	end
	inst.FindFirstChild = function(self, n)
		for _, c in ipairs(self.Children) do
			if c.Name == n then
				return c
			end
		end
		return nil
	end
	setmetatable(inst, {
		__newindex = function(t, k, v)
			if META_FIELDS[k] then
				rawset(t, k, v)
				return
			end
			assert(SCHEMA[class][k] ~= nil, "strict fake rejects "
				.. class .. "." .. tostring(k))
			checkType(class, k, v)
			rawset(t, k, v)
		end,
	})
	return inst
end

local fakeR = {
	Instance = { new = function(class)
		return FakeInst(class)
	end },
	Enum = {
		PartType = { Block = "Block" },
		Material = { SmoothPlastic = "SmoothPlastic" },
		SurfaceType = { Smooth = "Smooth" },
		NormalId = { Front = "Front" },
		ScaleType = { Crop = "Crop" },
		CameraType = { Scriptable = "Scriptable" },
		AutomaticSize = { Y = automaticSizeY },
		ScrollingDirection = { X = "X" },
		FillDirection = { Horizontal = "Horizontal" },
	},
	Vector3 = { new = function(x, y, z)
		assert(type(x) == "number", "Vector3 needs numbers")
		return { x = x, y = y, z = z, __type = "Vector3" }
	end },
	Vector2 = { new = function(x, y)
		assert(type(x) == "number" and type(y) == "number",
			"Vector2 needs numbers")
		return { x = x, y = y, __type = "Vector2" }
	end },
	UDim = { new = function(a, b)
		return { a = a, b = b, __type = "UDim" }
	end },
	UDim2 = {
		new = function(sx, ox, sy, oy)
			return { __type = "UDim2", sx = sx, ox = ox, sy = sy, oy = oy }
		end,
		fromScale = function(x, y)
			return { __type = "UDim2", sx = x, sy = y, ox = 0, oy = 0 }
		end,
	},
	CFrame = { new = function(a, b)
		assert(isVector3(a), "CFrame needs Vector3")
		if b ~= nil then
			assert(isVector3(b) or type(b) == "table", "CFrame lookAt invalid")
		end
		return { __type = "CFrame", pos = a }
	end },
	Color3 = { fromHex = function(h)
		assert(type(h) == "string" and #h == 7, "Color3.fromHex needs #RRGGBB")
		return { __type = "Color3", hex = h }
	end },
}
return { FakeSignal = FakeSignal, FakeInst = FakeInst, fakeR = fakeR }
