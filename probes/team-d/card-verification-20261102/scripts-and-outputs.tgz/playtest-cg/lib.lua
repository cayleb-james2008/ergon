-- lib.lua: direct battle maths through the repo's own Battles.buildSnapshot + Resolver (same call BattleService makes)
local Cards = dofile("./src/shared/content/Cards.luau")
local Resolver = dofile("./src/shared/combat/Resolver.luau")
local Battles = dofile("./src/shared/progression/Battles.luau")
local Config = dofile("./src/shared/progression/Config.luau")
local Bootstrap = dofile("./src/server/Bootstrap.luau")
local _, editionsById, encounters = Bootstrap.contentTables(Cards)
local L = { Cards=Cards, Resolver=Resolver, Battles=Battles, Config=Config, editionsById=editionsById, encounters=encounters }
L.ROUTES = {"enc-1","enc-2","enc-3","boss-1","w2-enc-1","w2-enc-2","w2-enc-3","boss-2","w3-enc-1","w3-enc-2","w3-enc-3","boss-3"}
-- Replicates BattleService.startBattle's snapshot step. levels: {cardId->level} or a number for all
function L.fight(deck, levels, route, seed, mult)
  local lv = {}
  for _,id in ipairs(deck) do lv[id] = type(levels)=="number" and levels or (levels[id] or 1) end
  local enc = encounters[route]
  local A = Battles.buildSnapshot(deck, editionsById, lv, enc.chapter, mult or {atk=1,hp=1})
  local B = Battles.buildEnemySnapshot(enc.enemyIds, editionsById)
  local r = Resolver.resolveBattle(A, B, {seed=seed, rulesVersion=Config.RULES_VERSION})
  return r
end
function L.rate(deck, levels, route, n, base)
  local w, t = 0, 0
  for i=1,n do
    local s = ((base or 0) + i*2654435761) % 4294967296
    local r = L.fight(deck, levels, route, s)
    if r.snapshot.winner=="A" then w=w+1 end
  end
  return w
end
function L.durationS(events, speed)
  local tl = require_timeline
  return nil
end
return L
