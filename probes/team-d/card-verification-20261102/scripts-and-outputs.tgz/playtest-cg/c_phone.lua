-- (c) How much of each card a phone player sees, from the client's own camera + card geometry constants.
local BattleScene = dofile("./src/client/BattleScene.luau")
local G = dofile("./src/client/Geometry.luau")
local spec = BattleScene.cameraSpec()
local pos, look, fov = spec.position, spec.lookAt, spec.fieldOfView
print(string.format("camera pos=(%.1f,%.1f,%.1f) lookAt=(%.1f,%.1f,%.1f) vertical FOV=%d deg", pos.x,pos.y,pos.z, look.x,look.y,look.z, fov))
print(string.format("card W=%.1f H=%.1f at anchors A x=%.1f, B x=%.1f, y=%.1f, z=%.1f", G.CARD_W,G.CARD_H,G.ANCHOR_A_X,G.ANCHOR_B_X,G.ANCHOR_Y,G.ANCHOR_Z))
local fx,fy,fz = look.x-pos.x, look.y-pos.y, look.z-pos.z
local n = math.sqrt(fx*fx+fy*fy+fz*fz); fx,fy,fz = fx/n,fy/n,fz/n
-- right = +X (camera looks toward -Z); up = (0,-fz,fy)... (perpendicular to f and right)
local ux,uy,uz = 0, -fz, fy
local function project(px,py,pz, W,H, hfovMode)
  local vx,vy,vz = px-pos.x, py-pos.y, pz-pos.z
  local depth = vx*fx+vy*fy+vz*fz
  local xc = vx
  local yc = vx*ux+vy*uy+vz*uz
  local t = math.tan(math.rad(fov)/2)
  local aspect = W/H
  local ndcx = xc/(depth*t*aspect)
  local ndcy = yc/(depth*t)
  return (ndcx*0.5+0.5)*W, (0.5-ndcy*0.5)*H, depth
end
local function visibleFraction(cx, W, H, top, bottom)
  -- integrate over the card rectangle; visible if inside [0,W] horizontally and [top,bottom] vertically
  local steps, vis, tot = 120, 0, 0
  for i=0,steps-1 do for j=0,steps-1 do
    local x = cx - G.CARD_W/2 + (i+0.5)/steps*G.CARD_W
    local y = G.ANCHOR_Y - G.CARD_H/2 + (j+0.5)/steps*G.CARD_H
    -- area element weight: screen area ~ nothing special; weight in card space (what fraction of the CARD you can see)
    local sx,sy = project(x,y,G.ANCHOR_Z,W,H)
    tot = tot+1
    if sx>=0 and sx<=W and sy>=top and sy<=bottom then vis=vis+1 end
  end end
  return vis/tot
end
for _,dev in ipairs({ {"phone portrait 390x844",390,844}, {"phone portrait 375x812",375,812}, {"desktop 1920x1080",1920,1080}, {"landscape phone 844x390",844,390}}) do
  local name,W,H = dev[1],dev[2],dev[3]
  print("== "..name.." (aspect "..string.format("%.3f",W/H)..") ==")
  -- horizontal half-extent in world units at the card plane (centre row)
  local x0 = project(-G.CARD_W/2 - 3.2 ,4,0,W,H)
  local sxL = project(-4.5,4,0,W,H); local sxR = project(-1.9,4,0,W,H)
  local sxL2 = project(1.9,4,0,W,H); local sxR2 = project(4.5,4,0,W,H)
  print(string.format("  card A edges at screen x = %.0f .. %.0f px ; card B = %.0f .. %.0f px (screen width %d)", sxL,sxR,sxL2,sxR2,W))
  local fA = visibleFraction(G.ANCHOR_A_X,W,H,-1e9,1e9)
  local fB = visibleFraction(G.ANCHOR_B_X,W,H,-1e9,1e9)
  print(string.format("  at rest, full-screen 3D view: card A %.1f%% visible, card B %.1f%% visible", fA*100,fB*100))
  -- unobstructed band for portrait: top HUD stack ends ~ y=152 (Title y60+44, data 108+44) ; HUD TopHP 8..(8+0.05H+44); bottom control bar top = .95H-160-.16H
  local topPx = 152
  local barTop = 0.95*H-160-0.16*H
  local fA2 = visibleFraction(G.ANCHOR_A_X,W,H,topPx,barTop)
  print(string.format("  ...also excluding HUD bands (y<%d and y>%.0f): card A %.1f%% visible", topPx, barTop, fA2*100))
  -- at contact (attacker lunges): attacker centre x = contactX
  local cA = G.contactX("A")
  print(string.format("  attacker A at contact centre x=%.2f: %.1f%% visible", cA, visibleFraction(cA,W,H,-1e9,1e9)*100))
  local wind = G.windupX("A",false)
  print(string.format("  attacker A at wind-up centre x=%.2f: %.1f%% visible", wind, visibleFraction(wind,W,H,-1e9,1e9)*100))
  -- how much of the battle time is the card at rest vs lunging? (strike 0.55s of which at-rest-side visible fraction changes)
end
