-- play.lua: player-level helpers built on harness.lua (everything goes through button presses)
local H = dofile(os.getenv("PLAYDIR").."/harness.lua")
local P = { H = H }

-- Go to a top-level screen the way a player does: nav tab, or the screen's own "back" button.
function P.to(g, screen)
  if g:cur() == screen then return end
  if g:cur() == "encounter" then
    if screen == "worlds" then g:press("to-worlds") return end
    g:press("to-worlds")
  end
  local s = g.app.screens[g:cur()]
  if s.navButtons and s.navButtons[screen] then g:nav(screen) return end
  -- screens off the tab bar: through the MORE hub
  g:nav("settings")
  g:press("hub-" .. screen)
end

function P.cardLevels(g)
  local d = g:profileRaw()
  return d.run.cardLevels, d.run.cardXp
end

-- Fight one route start-to-claim. mode = "watch" or "skip". Returns winner ("A"/"B"/"tie"), claimResult text
function P.fight(g, route, mode, opts)
  opts = opts or {}
  P.to(g, "worlds")
  local ok = g:press("route-" .. route)
  if not ok or g:cur() ~= "encounter" then return nil, "route did not start: " .. tostring(g:status()) end
  local secs = g:playBattle(mode)
  if mode == "skip" and g.app.battle and not g.app.battle.settled then g:playBattle("watch") end
  local winner = g.app.lastBattleWinner
  if not g.app.battle then return nil, "no battle" end
  g:press("reward-claim")
  return winner, g:status(), secs
end

-- True deck of the three starters in the standard order
function P.starterDeck(g)
  g:press("tutorial-next")           -- START -> TEAM
  g:press("deck-save")               -- fills with alphabetical first 4 owned (the three starters)
end

-- Level milestones read from the hidden raw profile (the UI itself shows none of this)
function P.watchMarks(g, wins)
  local d = g:profileRaw()
  if d.run.level >= 2 then g:mark("first run level-up (run level 2)") end
  local maxL = 1
  for _, lv in pairs(d.run.cardLevels) do if lv > maxL then maxL = lv end end
  if maxL >= 2 then g:mark("first card level-up") end
  if d.run.bossClaimed then g:mark("first boss win claimed") end
  if wins and wins >= 1 then g:mark("first win claimed") end
end
return P
