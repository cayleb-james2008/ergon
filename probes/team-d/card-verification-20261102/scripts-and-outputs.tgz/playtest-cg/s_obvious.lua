-- Session B2: "just keep pressing the obvious button" player. Policy: follow the guided buttons only
-- (tutorial-next -> deck-save -> to-worlds -> worlds-next / reward-next, watch every duel, claim every result).
local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local seed = tonumber(arg[1]) or 1
local mode = arg[2] or "watch"
local quiet = arg[3] ~= "v"
local CAP = tonumber(arg[4]) or 400
local g = H.new(seed, {quiet = quiet})
local battles, wins, losses = 0, 0, 0
local lastRoute
local routeLog = {}
g:press("tutorial-next")
g:press("deck-save")
g:press("to-worlds")
g:say("the player now follows: Enter next duel -> watch -> Claim -> Continue ...")
local function wallOutcome(route, w) routeLog[#routeLog+1] = route .. ":" .. tostring(w) end
local firstBoss = false
while battles < CAP do
  -- on worlds screen: press the big action button
  if g:cur() ~= "worlds" then
    if g:cur() == "rewards" and g:has("reward-next") then g:press("reward-next") else P.to(g, "worlds") ; g:press("worlds-next") end
  else
    g:press("worlds-next")
  end
  if g:cur() ~= "encounter" then g:say("could not start a battle: %s", tostring(g:status())); break end
  local sel = g.app.selectedEncounterId
  do local tl = g.app.battle.timeline; local d = 0
     for _, e in ipairs(tl.events) do d = d + H.Timeline.eventDuration(tl, e) end
     g.watchEquiv = (g.watchEquiv or 0) + d end
  g:playBattle(mode == "skip" and "skip" or "watch")
  if mode == "skip" and g.app.battle and not g.app.battle.settled then g:playBattle("watch") end
  battles = battles + 1
  local w = g.app.lastBattleWinner
  g:press("reward-claim")
  if w == "A" then wins = wins + 1 else losses = losses + 1 end
  wallOutcome(sel, w)
  P.watchMarks(g, wins)
  local d = g:profileRaw()
  if battles % 20 == 0 or (g.marks["first boss win claimed"]) then
    local lv = d.run.cardLevels
    g:say("battle %d on %s -> %s ; card levels %s/%s/%s ; coins %d", battles, sel, tostring(w),
      tostring(lv["BC-ASTA-01"]), tostring(lv["NR-NARUTO-01"]), tostring(lv["VS-THORFINN-01"]), d.run.currency)
  end
  if d.run.bossClaimed then break end
end
-- compress the route log
local compact, prev, cnt = {}, nil, 0
for _, r in ipairs(routeLog) do
  if r == prev then cnt = cnt + 1 else if prev then compact[#compact+1] = prev .. " x" .. cnt end prev, cnt = r, 1 end
end
if prev then compact[#compact+1] = prev .. " x" .. cnt end
print(string.format("RESULT seed=%d mode=%s battles=%d wins=%d losses=%d actions=%d total_s=%.0f forced_s=%.0f human_s=%.0f bossClaimed=%s",
  seed, mode, battles, wins, losses, g.actions, g.t - g.t0, g.forcedS, g.humanS, tostring(g:profileRaw().run.bossClaimed)))
print(string.format("  watch-at-1x equivalent of all %d duels: %.0f s (%.1f min)", battles, g.watchEquiv or 0, (g.watchEquiv or 0)/60))
print("  ROUTE LOG: " .. table.concat(compact, " | "))
for k, v in pairs(g.marks) do print(string.format("  MARK %-32s actions=%3d t=%s", k, v.actions, H.fmt(v.secs))) end
-- Text the player is looking at on the wall
if g.app.screens.rewards then print("  last reward text: " .. tostring(g.app.screens.rewards.data.Text)) end
