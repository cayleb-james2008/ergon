-- Session A: the first 15 minutes of a curious new player who reads screens and follows the hints.
local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local seed = tonumber(arg[1]) or 3
local quiet = arg[2] == "q"
local BUDGET = 900
local g = H.new(seed, {quiet = quiet})
local function el() return g.t - g.t0 end
local CardsById = {}
for _, e in ipairs(H.Cards.EDITIONS) do CardsById[e.id] = e end
local rank = {Common=1,Uncommon=2,Rare=3,Epic=4,Legendary=5,Mythic=6}

g:read("START screen")
g:press("tutorial-roll", "the big button on the first screen")
g:read("SUMMON screen")
-- roll, then impatiently roll again
g:press("roll-free"); g:press("roll-free", "impatient second tap")
g:wait(6.2, true); g:say("(waits for the six-second timer; the screen shows no timer)")
for i = 1, 3 do g:press("roll-free"); g:wait(6.2, true) end
g:press("roll-odds"); g:read("odds")
g:press("autoroll-toggle", "curious about auto-roll")
g:read("after auto-roll toggle")
local raw = g:profileRaw(); g:say("(hidden) server autoRoll flag is now: %s", tostring(raw.run.autoRoll))
g:press("autoroll-toggle", "tries again"); raw = g:profileRaw(); g:say("(hidden) server autoRoll flag is now: %s", tostring(raw.run.autoRoll))
-- inspect collection
g:nav("inventory"); g:read("CARDS")
-- deck: pick the four best by rarity then ATK+HP as shown on the cards
g:nav("deck"); g:read("TEAM (empty)")
local owned = {}
for id in pairs(g:profile().collection) do owned[#owned+1] = id end
table.sort(owned, function(a, b)
  local A, B = CardsById[a], CardsById[b]
  if rank[A.rarity] ~= rank[B.rarity] then return rank[A.rarity] > rank[B.rarity] end
  return A.atk + A.hp > B.atk + B.hp end)
for i = 1, math.min(4, #owned) do g:press("add-" .. owned[i], CardsById[owned[i]].alias .. " (" .. CardsById[owned[i]].rarity .. ")") end
g:press("deck-save"); g:read("TEAM saved?")
g:press("to-worlds"); g:read("WORLDS")
local fights, W, L = 0, 0, 0
while el() < BUDGET do
  if g:cur() == "rewards" and g:has("reward-next") and g:status() ~= nil then g:press("reward-next") else g:press("worlds-next") end
  if g:cur() ~= "encounter" then g:say("stuck: %s", tostring(g:status())); break end
  local sel = g.app.selectedEncounterId
  local secs = g:playBattle("watch")
  local w = g.app.lastBattleWinner; fights = fights + 1
  if fights <= 3 then g:read("result of " .. sel) end
  g:press("reward-claim")
  if w == "A" then W = W + 1 else L = L + 1 end
  g:say("duel %d on %s lasted %.1fs -> %s | %s", fights, sel, secs, w == "A" and "WON" or "LOST", tostring(g:status()))
  P.watchMarks(g, W)
end
local d = g:profileRaw()
g:say("END OF 15 MINUTES: duels=%d wins=%d losses=%d actions=%d cleared=%s", fights, W, L, g.actions,
  (function() local t = {} for k in pairs(d.run.encounters) do t[#t+1] = k end table.sort(t) return table.concat(t, ",") end)())
g:say("(hidden) card levels: %s", (function() local t = {} for k, v in pairs(d.run.cardLevels) do t[#t+1] = k .. "=" .. v end table.sort(t) return table.concat(t, " ") end)())
g:say("(hidden) coins=%d run level=%d xp=%d", d.run.currency, d.run.level, d.run.xp)
for k, v in pairs(g.marks) do print(string.format("  MARK %-32s actions=%3d t=%s", k, v.actions, H.fmt(v.secs))) end
