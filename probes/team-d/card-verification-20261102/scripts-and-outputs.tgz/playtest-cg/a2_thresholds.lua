local L = dofile(os.getenv("PLAYDIR").."/lib.lua")
local N = tonumber(arg[1]) or 1000
local S = {"NR-NARUTO-01","VS-THORFINN-01","BC-ASTA-01"}
local perms = {{1,2,3},{1,3,2},{2,1,3},{2,3,1},{3,1,2},{3,2,1}}
print("== Level-10 starter deck, 12 routes x "..N.." seeds, all 6 orders of the 3 starters ==")
local tot, win = 0, 0
for _,p in ipairs(perms) do
  local deck = {S[p[1]],S[p[2]],S[p[3]]}
  local row = {}
  local w12 = 0
  for _,rt in ipairs(L.ROUTES) do
    local w = L.rate(deck, 10, rt, N, 991)
    w12 = w12 + w; tot = tot + N; win = win + w
    row[#row+1] = w
  end
  print(table.concat(deck,">"), table.concat(row,","))
end
print(string.format("TOTAL level-10 starter wins %d / %d", win, tot))
print()
print("== Level needed (first level with 100% over "..N.." seeds AND stays 100% up to 15), by route, best/worst order ==")
for _,rt in ipairs(L.ROUTES) do
  local res = {}
  for _,p in ipairs(perms) do
    local deck = {S[p[1]],S[p[2]],S[p[3]]}
    local first
    for lv=1,15 do
      local ok=true
      for l2=lv,15 do if L.rate(deck,l2,rt,N//4,5)<N//4 then ok=false break end end
      if ok then first=lv break end
    end
    res[#res+1]=first
  end
  print(rt, "needs level (per order): "..table.concat(res,","))
end
