local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local g = P.H.new(1, {quiet=true})
P.starterDeck(g)
for i=1,4 do
  P.to(g,"worlds")
  g:press("route-enc-1")
  local b = g.app.battle
  print("battle",i,"events",#b.timeline.events,"tl.speed",b.timeline.speed,"prefs.speed",g.app.store.prefs.speed, "server speed", tostring(g.app.profile.settings.speed))
  local s = g:playBattle("watch")
  print("  secs", s, "winner", g.app.lastBattleWinner)
  g:press("reward-claim")
end
