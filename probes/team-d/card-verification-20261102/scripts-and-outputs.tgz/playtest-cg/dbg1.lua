local L = dofile(os.getenv("PLAYDIR").."/lib.lua")
local T = dofile("./src/client/Timeline.luau")
local deck = {"BC-ASTA-01","NR-NARUTO-01","VS-THORFINN-01"}
for _,lv in ipairs({1,3,6,10}) do for _,rt in ipairs({"enc-1","boss-2","boss-1"}) do
  local r = L.fight(deck, lv, rt, 12345)
  local tl = T.new("x", r.events, nil, {speed=1})
  local tot=0; for _,e in ipairs(r.events) do tot = tot + T.eventDuration(tl,e) end
  local strikes=0; for _,e in ipairs(r.events) do if e.kind=="strike" then strikes=strikes+1 end end
  print(lv, rt, "winner", r.snapshot.winner, "turns", r.snapshot.turns, "events", #r.events, "strikes", strikes, string.format("dur@1x %.1fs", tot))
end end
