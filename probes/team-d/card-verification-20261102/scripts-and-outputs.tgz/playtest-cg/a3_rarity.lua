local L = dofile(os.getenv("PLAYDIR").."/lib.lua")
local N = tonumber(arg[1]) or 400
local function show(name, deck, levels)
  io.write(string.format("%-58s", name))
  for _,rt in ipairs(L.ROUTES) do io.write(string.format("%4d", math.floor(L.rate(deck, levels, rt, N, 31)*100/N+.5))) end
  print()
end
io.write(string.format("%-58s","win% by route (N="..N..")  ->"))
for _,rt in ipairs(L.ROUTES) do io.write(string.format("%4s", rt:gsub("enc%-","e"):gsub("boss%-","B"):gsub("w(%d)%-","w%1"))) end print()
local S = {"NR-NARUTO-01","VS-THORFINN-01","BC-ASTA-01"}
show("3 starters L1", S, 1)
show("3 starters L5", S, 5)
show("3 starters L10", S, 10)
-- a Common 4th card (Dojo Teacher) ...
show("starters+Dojo Teacher (Common) L1", {S[1],S[2],S[3],"VG-HEAD-01"}, 1)
show("starters+Axe Berserker (Rare) L1", {S[1],S[2],S[3],"VS-BEAR-01"}, 1)
show("starters+Black Swordsman (Epic) L1", {S[1],S[2],S[3],"BK-GUTS-01"}, 1)
show("starters+Thousand-Blade Noble (MYTHIC) L1", {S[1],S[2],S[3],"BL-BYAKUYA-01"}, 1)
-- Best-in-slot decks at level 1: lead with strongest
show("Mythic+Legendary+Legendary+Epic L1", {"BL-BYAKUYA-01","NR-KAKASHI-01","MHA-FROSTBURN-01","BK-GUTS-01"}, 1)
show("Epic x4 (Guts,Blast,Rival,Shadow) L1", {"BK-GUTS-01","MHA-BLAST-01","VG-RIVAL-01","NR-SHADOW-01"}, 1)
show("Rare x4 (Ichigo,Bear,Deku,Namek) L1", {"BL-ICHIGO-01","VS-BEAR-01","MHA-DEKU-01","DB-NAMEK-01"}, 1)
show("Epic x4 L3", {"BK-GUTS-01","MHA-BLAST-01","VG-RIVAL-01","NR-SHADOW-01"}, 3)
show("Epic x4 L6", {"BK-GUTS-01","MHA-BLAST-01","VG-RIVAL-01","NR-SHADOW-01"}, 6)
-- The same level, rarer vs starters: lowest level where each deck is 100% on every route
local function allLevel(deck)
  for lv=1,20 do
    local ok=true
    for _,rt in ipairs(L.ROUTES) do if L.rate(deck, lv, rt, 200, 8) < 200 then ok=false break end end
    if ok then return lv end
  end
end
print()
print("Lowest card level at which the deck wins ALL 12 routes 200/200:")
print("  3 starters                      ", allLevel(S))
print("  starters + Common 4th (Dojo)    ", allLevel({S[1],S[2],S[3],"VG-HEAD-01"}))
print("  starters + Epic 4th (Guts)      ", allLevel({S[1],S[2],S[3],"BK-GUTS-01"}))
print("  starters + MYTHIC 4th           ", allLevel({S[1],S[2],S[3],"BL-BYAKUYA-01"}))
print("  Epic x4                         ", allLevel({"BK-GUTS-01","MHA-BLAST-01","VG-RIVAL-01","NR-SHADOW-01"}))
print("  Mythic+2 Legendary+Epic         ", allLevel({"BL-BYAKUYA-01","NR-KAKASHI-01","MHA-FROSTBURN-01","BK-GUTS-01"}))
print("  Rare x4                         ", allLevel({"BL-ICHIGO-01","VS-BEAR-01","MHA-DEKU-01","DB-NAMEK-01"}))
