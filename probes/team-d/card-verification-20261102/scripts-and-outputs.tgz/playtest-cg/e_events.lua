local L = dofile(os.getenv("PLAYDIR").."/lib.lua")
local T = dofile("./src/client/Timeline.luau")
local deck = {"BC-ASTA-01","NR-NARUTO-01","VS-THORFINN-01"}
local kinds, nfights, totalDur, strikeDur = {}, 0, 0, 0
local durs = {}
local byRoute = {}
for _, rt in ipairs(L.ROUTES) do
  for _, lv in ipairs({1, 6, 10}) do
    local ds, sk = {}, {}
    for i = 1, 100 do
      local r = L.fight(deck, lv, rt, (i * 2654435761 + 5) % 4294967296)
      local tl = T.new("x", r.events, nil, {speed = 1})
      local d, s = 0, 0
      for _, e in ipairs(r.events) do
        local ed = T.eventDuration(tl, e); d = d + ed
        kinds[e.kind] = (kinds[e.kind] or 0) + 1
        if e.kind == "strike" then s = s + 1; strikeDur = strikeDur + ed end
      end
      totalDur = totalDur + d; nfights = nfights + 1
      ds[#ds+1] = d; sk[#sk+1] = s
    end
    table.sort(ds); table.sort(sk)
    byRoute[#byRoute+1] = string.format("%-9s L%-2d  duel at 1x: min %4.1fs  median %4.1fs  max %4.1fs | strikes median %d", rt, lv, ds[1], ds[50], ds[100], sk[50])
  end
end
for _, l in ipairs(byRoute) do print(l) end
local ks = {}
for k, v in pairs(kinds) do ks[#ks+1] = k end table.sort(ks)
local tot = 0 for _, k in ipairs(ks) do tot = tot + kinds[k] end
for _, k in ipairs(ks) do print(string.format("  event %-14s %6d  (%.1f%%)", k, kinds[k], kinds[k]*100/tot)) end
print(string.format("share of presentation time that is a strike animation (wind-up, lunge, edge contact, recoil): %.0f%%", strikeDur*100/totalDur))
print(string.format("avg duel %.1fs at 1x over %d duels; at 2x %.1fs; at 4x %.1fs", totalDur/nfights, nfights, totalDur/nfights/2, totalDur/nfights/4))
