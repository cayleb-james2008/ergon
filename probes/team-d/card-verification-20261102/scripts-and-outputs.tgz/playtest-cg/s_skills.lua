-- Finding (d): do skill points change anything? Same seed, same presses, with and without spending.
local P = dofile(os.getenv("PLAYDIR").."/play.lua")
local H = P.H
local mode = arg[1] or "honest"      -- honest: 3 points earned by play; fixture: 16 points seeded directly (flagged)
local NSEEDS = tonumber(arg[2]) or 10
local function fixture(g)
  local d = g:profileRaw()
  local ident = g.h.store.identity(g.h.store, g.userId, "fixture-skillpts", math.floor(g.t), { epoch = d.session.epoch, seq = d.run.reqHighWater + 1 })
  ident.op.expectedRevision = ident.revision
  local r = g.h.store.runOp(g.h.store, g.userId, ident.op, function(cur) cur.account.skillPoints = 16; return cur, {}, nil end)
  assert(r.status == "Committed", tostring(r.reason))
end
local nodes3 = {"prep-atk-1","prep-atk-1","prep-hp-1"}
local nodesMax = {"prep-atk-1","prep-atk-1","prep-atk-2","prep-atk-2","prep-hp-1","prep-hp-1","prep-hp-2","prep-hp-2",
  "train-xp-1","train-xp-1","train-xp-1","train-xp-2","train-xp-2","train-xp-2","restore-bench-1","restore-bench-1"}
local function session(seed, spend)
  local g = H.new(seed, {quiet = true})
  P.starterDeck(g)
  local need = {["enc-1"]=1,["enc-2"]=1,["enc-3"]=1,["w2-enc-1"]=2,["w2-enc-2"]=3,["w2-enc-3"]=4,["boss-2"]=6}
  local function minL() local lv = P.cardLevels(g); local m = 99 for _, id in ipairs(g:profileRaw().run.deck) do m = math.min(m, lv[id] or 1) end return m end
  for _, rt in ipairs({"enc-1","enc-2","enc-3","w2-enc-1","w2-enc-2","w2-enc-3","boss-2"}) do
    while minL() < need[rt] do P.fight(g, "enc-1", "skip") end
    repeat local w = P.fight(g, rt, "skip") until w == "A" or g:profileRaw().run.bossClaimed
  end
  P.to(g, "upgrade"); g:press("rank-claim")
  if mode == "fixture" then fixture(g); g:press("upgrade-refresh") end
  local used = 0
  if spend then
    for _, n in ipairs(mode == "fixture" and nodesMax or nodes3) do g:press("skill-" .. n); used = used + 1 end
    g:press("skills-confirm")
  end
  local d = g:profileRaw()
  local rec = { alloc = {}, points = d.account.skillPoints, uiText = g.app.screens.upgrade.data.Text }
  for k, v in pairs(d.account.skillAlloc) do rec.alloc[#rec.alloc+1] = k .. "=" .. v end
  table.sort(rec.alloc)
  rec.battles = {}
  local plan = {"boss-2","boss-2","boss-2","w3-enc-1","w3-enc-2","w3-enc-3","boss-3","boss-3","boss-1","boss-1","boss-1","boss-1","enc-1","enc-1","enc-1","enc-1"}
  for _, rt in ipairs(plan) do
    P.to(g, "worlds"); g:press("route-" .. rt)
    local pb = g:profileRaw().run.pendingBattle
    local s = {}
    for _, f in ipairs(pb.snapshotA) do s[#s+1] = f.cardId .. ":" .. f.hp .. "/" .. f.atk end
    local rw = g:profileRaw().run.pendingReward
    g:playBattle("skip")
    g:press("reward-claim")
    local d2 = g:profileRaw()
    local lv, xp = {}, {}
    for _, id in ipairs(d2.run.deck) do lv[#lv+1] = id .. "L" .. d2.run.cardLevels[id] .. "x" .. (d2.run.cardXp[id] or 0) end
    rec.battles[#rec.battles+1] = table.concat({rt, table.concat(s, ","), rw.winner, rw.turns, rw.eventHash, "rew" .. rw.xp .. "/" .. rw.currency, table.concat(lv, ","), "runxp" .. d2.run.level .. "/" .. d2.run.xp, "coins" .. d2.run.currency}, " | ")
  end
  return rec
end
local diffBattles, totalBattles, diffSeeds = 0, 0, 0
for seed = 1, NSEEDS do
  local a, b = session(seed, true), session(seed, false)
  local nd = 0
  for i = 1, #a.battles do totalBattles = totalBattles + 1; if a.battles[i] ~= b.battles[i] then nd = nd + 1; diffBattles = diffBattles + 1
    if diffBattles <= 3 then print("DIFF seed " .. seed .. "\n  with   : " .. a.battles[i] .. "\n  without: " .. b.battles[i]) end end end
  if nd > 0 then diffSeeds = diffSeeds + 1 end
  if seed == 1 then
    print("seed 1 allocation saved on server (with spend): " .. table.concat(a.alloc, ","))
    print("seed 1 upgrade screen text (with):    " .. a.uiText:gsub("\n", " / "))
    print("seed 1 upgrade screen text (without): " .. b.uiText:gsub("\n", " / "))
    print("seed 1 sample battle record (with)   : " .. a.battles[1])
    print("seed 1 sample battle record (without): " .. b.battles[1])
    print("seed 1 boss-1 L? record (with)   : " .. a.battles[9])
  end
end
print(string.format("MODE %s: %d seeds x %d battles each = %d battle pairs; pairs that differ in ANY field (stats snapshot, winner, turns, event hash, XP, currency, levels): %d (seeds with any difference: %d)", mode, NSEEDS, 16, totalBattles, diffBattles, diffSeeds))
