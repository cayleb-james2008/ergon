local L = dofile(os.getenv("PLAYDIR").."/lib.lua")
local N = tonumber(arg[1]) or 400
local deck = {"BC-ASTA-01","NR-NARUTO-01","VS-THORFINN-01"} -- the 3 starters, alphabetical (what an empty-draft Save produces)
print("== Win % (of "..N.." seeds), 3 starters, all at card level L; columns = L ==")
io.write(string.format("%-9s %-15s","route","enemy"))
for lv=1,14 do io.write(string.format("%5d",lv)) end print()
for _,rt in ipairs(L.ROUTES) do
  local e = L.encounters[rt]
  io.write(string.format("%-9s %-15s",rt, e.enemyIds[1]))
  for lv=1,14 do
    local w = L.rate(deck, lv, rt, N, 77)
    io.write(string.format("%5d", math.floor(w*100/N+0.5)))
  end
  print(string.format("   (chapter %d, cap %d)", e.chapter, L.Config.CHAPTER_CAPS[e.chapter]))
end
