local H = dofile(os.getenv("PLAYDIR").."/harness.lua")
local g = H.new(5)
g:read("START")
g:press("tutorial-next")
g:read("deck (empty)")
local v=g:see(); for _,b in ipairs(v.buttons) do print("  btn",b.id,b.text,b.active) end
g:press("deck-save","press save on an empty deck")
g:press("add-BC-ASTA-01"); g:press("add-NR-NARUTO-01"); g:press("add-VS-THORFINN-01")
g:read("deck after 3 adds")
g:press("deck-save")
g:read("after save")
local v=g:see(); for _,b in ipairs(v.buttons) do print("  btn",b.id,b.text,b.active) end
