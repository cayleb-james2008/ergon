local H = dofile(os.getenv("PLAYDIR").."/harness.lua")
local g = H.new(1)
g:read("first screen")
local v=g:see(); for _,b in ipairs(v.buttons) do print("  btn",b.id,b.text,b.active) end
g:press("tutorial-roll")
g:read("roll screen")
g:press("roll-free")
g:press("roll-free","immediately again")
