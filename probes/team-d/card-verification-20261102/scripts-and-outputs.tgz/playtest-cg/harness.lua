-- harness.lua  (PLAYTESTER driver; run with cwd = the candidate export, lua5.4)
-- Boots the REAL server (Bootstrap.build over the repo's own MemoryAdapter) and the REAL
-- client App (the repo's strict fake Roblox runtime, extracted verbatim from its tests),
-- then lets a "player" press buttons by name and read the texts the UI shows.
-- Nothing in the candidate is modified. All state lives in memory.

local PLAY = os.getenv("PLAYDIR")
local fake = dofile(PLAY .. "/fakert.lua")
local fakeR, FakeSignal, FakeInst = fake.fakeR, fake.FakeSignal, fake.FakeInst

local function client(n) return dofile("./src/client/" .. n .. ".luau") end
local function shared(p) return dofile("./src/shared/" .. p .. ".luau") end
local function server(n) return dofile("./src/server/" .. n .. ".luau") end

local H = {}
H.Cards = shared("content/Cards")
H.Config = shared("progression/Config")
H.Resolver = shared("combat/Resolver")
H.Battles = shared("progression/Battles")
H.Progression = shared("progression/Progression")
local Bootstrap = server("Bootstrap")
local Remotes = server("Remotes")
local MemoryAdapter = server("MemoryAdapter")
H.Bootstrap, H.Remotes = Bootstrap, Remotes

local Theme, State, World = client("Theme"), client("State"), client("World")
local CardView, Geometry, Timeline = client("CardView"), client("Geometry"), client("Timeline")
local BattleScene, Screens = client("BattleScene"), client("Screens")
local ClientProtocol, UiView = client("ClientProtocol"), client("UiView")
local Actions, EncounterRoutes = client("Actions"), client("EncounterRoutes")
local BattlePresenter, App = client("BattlePresenter"), client("App")
H.Timeline, H.Geometry, H.State, H.ClientProtocol = Timeline, Geometry, State, ClientProtocol

local mods = {
	Theme = Theme, State = State, World = World, CardView = CardView,
	Geometry = Geometry, Timeline = Timeline, BattleScene = BattleScene,
	Screens = Screens, ClientProtocol = ClientProtocol, Config = H.Config,
	Cards = H.Cards, UiView = UiView, Actions = Actions,
	BattlePresenter = BattlePresenter, EncounterRoutes = EncounterRoutes,
}

local USER = 7001
-- Human-time model (assumptions, stated in the report): one deliberate tap, and a read of a new screen.
H.TAP_S = 1.5
H.READ_S = 3.0

local Game = {}
Game.__index = Game

-- opts: tap, quiet, userId
function H.new(seed, opts)
	opts = opts or {}
	math.randomseed(seed)
	local g = setmetatable({}, Game)
	g.seed = seed
	g.t = 2000000.0            -- seconds, server clock = floor(t)
	g.actions = 0              -- button presses by the player
	g.humanS = 0               -- time spent by player taps/reads (modelled)
	g.forcedS = 0              -- time the game itself forces (battle playback, cooldown waits)
	g.log = {}
	g.refusals = {}            -- {cmd, status, reason, shown}
	g.calls = {}               -- wire commands
	g.marks = {}               -- milestones -> {actions, total seconds, forced seconds}
	g.quiet = opts.quiet
	g.TAP = opts.tap or H.TAP_S
	g.adapter = MemoryAdapter.new()
	g.h = Bootstrap.build({
		adapter = g.adapter,
		clock = function() return math.floor(g.t) end,
		drawInt = function(upper) return math.random(1, upper) end,
		drawSeed = function() return Bootstrap.randomSeed(math.random) end,
		resolver = H.Resolver, Cards = H.Cards, serverId = "srv-playtest",
	})
	g.userId = opts.userId or USER
	g.t0 = g.t
	g:join()
	return g
end

function Game:join()
	local joined = Bootstrap.playerAdded(self.h, self.userId)
	self.joinStatus = joined
	-- The repo's FakeSignal.Disconnect is a no-op, which would stack frame listeners across battles
	-- (an artefact of the fake, not of the game). Use a stepper whose Disconnect really disconnects.
	local listeners = {}
	self.stepper = {
		Connect = function(_, fn)
			local entry = { fn = fn }
			listeners[#listeners + 1] = entry
			return { Disconnect = function() entry.dead = true end }
		end,
		Fire = function(_, ...)
			for i = #listeners, 1, -1 do if listeners[i].dead then table.remove(listeners, i) end end
			for _, e in ipairs({ table.unpack(listeners) }) do if not e.dead then e.fn(...) end end
		end,
	}
	self.playerGui = FakeInst("Folder")
	self.workspaceFake = { CurrentCamera = nil }
	self.transport = function(req)
		self.calls[#self.calls + 1] = req.command
		local resp = Remotes.dispatch(self.h.router, self.userId, req)
		if resp.status ~= "Committed" and resp.status ~= "AlreadyCommitted" then
			self.refusals[#self.refusals + 1] = { cmd = req.command, status = resp.status,
				reason = resp.reason, t = self.t - self.t0, retryAfterS = resp.retryAfterS }
			self.lastRefusal = self.refusals[#self.refusals]
		end
		self.lastResp = resp
		return resp
	end
	self.app = App.new({ R = fakeR, transport = self.transport, stepper = self.stepper,
		store = State.new(), mods = mods })
	App.boot(self.app, self.playerGui, self.workspaceFake)
end

-- Leave and come back after `secs` seconds (new client, same saved server profile).
function Game:reconnect(secs)
	Bootstrap.playerRemoving(self.h, self.userId)
	self.t = self.t + secs
	self:join()
end

function Game:say(...)
	local s = string.format("[t=%6.1fs a=%3d] ", self.t - self.t0, self.actions) .. string.format(...)
	self.log[#self.log + 1] = s
	if not self.quiet then print(s) end
end

function Game:wait(secs, forced)
	self.t = self.t + secs
	if forced then self.forcedS = self.forcedS + secs else self.humanS = self.humanS + secs end
end

function Game:mark(name)
	if not self.marks[name] then
		self.marks[name] = { actions = self.actions, secs = self.t - self.t0, forced = self.forcedS,
			human = self.humanS }
		self:say("MILESTONE %s", name)
	end
end

function Game:cur() return self.app.current end
function Game:profile() return self.app.profile end
function Game:status() return self.app.statusMessage end

-- What is on screen: body text, feedback line, buttons.
function Game:see()
	local s = self.app.screens[self.app.current]
	local out = { screen = self.app.current, data = s.data and s.data.Text or "",
		feedback = s.feedback and s.feedback.Text or "", buttons = {} }
	for id, b in pairs(s.buttons) do
		out.buttons[#out.buttons + 1] = { id = id, text = b.Text, active = b.Active ~= false }
	end
	table.sort(out.buttons, function(a, b) return a.id < b.id end)
	return out
end

function Game:buttonText(id)
	local s = self.app.screens[self.app.current]
	return s.buttons[id] and s.buttons[id].Text or nil
end

function Game:has(id)
	local s = self.app.screens[self.app.current]
	return s.buttons[id] ~= nil
end

-- Press a button on the CURRENT screen (the player can only press what they see).
function Game:press(id, note)
	local s = self.app.screens[self.app.current]
	local b = s.buttons[id]
	if b == nil then
		error("player cannot see button '" .. id .. "' on screen '" .. self.app.current .. "'", 2)
	end
	self:wait(self.TAP)
	self.actions = self.actions + 1
	local before = #self.refusals
	-- Inactive buttons do not fire in Roblox (Active=false stops input); mirror that.
	if b.Active == false then
		self:say("press %s/%s  (button is greyed out; nothing happens)%s", self.app.current, id,
			note and ("  -- " .. note) or "")
		return false
	end
	local from = self.app.current
	b.Activated:Fire()
	local shown = self.app.statusMessage
	if #self.refusals > before then
		self.refusals[#self.refusals].shown = shown
		self.refusals[#self.refusals].screen = from
	end
	self:say("press %s/%s -> screen=%s | status: %s%s", from, id, self.app.current,
		tostring(shown), note and ("  -- " .. note) or "")
	return true
end

function Game:nav(target)
	local s = self.app.screens[self.app.current]
	local b = s.navButtons and s.navButtons[target]
	if b == nil then error("no tab '" .. target .. "' on " .. self.app.current, 2) end
	self:wait(self.TAP); self.actions = self.actions + 1
	b.Activated:Fire()
	self:say("tab -> %s", self.app.current)
end

-- Read the screen (costs reading time).
function Game:read(label)
	self:wait(H.READ_S)
	local v = self:see()
	local d = (v.data or ""):gsub("\n", " / ")
	self:say("READ %s [%s]: %s || feedback: %s", label or "", v.screen, d, v.feedback)
	return v
end

-- Advance the battle presentation until it settles. mode: "skip" or anything else = watch at pref speed.
-- Returns seconds of presentation the player sat through.
function Game:playBattle(mode)
	local app = self.app
	if app.battle == nil then return 0 end
	if mode == "skip" then
		self:press("battle-skip")
		return 0
	end
	local dt, spent = 1 / 30, 0
	while app.battle ~= nil and not app.battle.settled and spent < 600 do
		self.stepper:Fire(dt)
		self:wait(dt, true)
		spent = spent + dt
	end
	return spent
end

function Game:profileRaw() return self.h.store.read(self.h.store, self.userId) end

function H.fmt(t) return string.format("%d:%02d", math.floor(t / 60), math.floor(t % 60)) end

H.fakeR, H.FakeInst, H.FakeSignal = fakeR, FakeInst, FakeSignal
return H
